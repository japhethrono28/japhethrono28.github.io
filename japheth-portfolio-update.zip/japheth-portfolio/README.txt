JAPHETH RONO — GITHUB PAGES WEBSITE

Files:
- index.html
- assets/japheth.jpg

To publish:
1. Open https://github.com/japhethrono28
2. Open the repository used for japhethrono28.github.io (usually named japhethrono28.github.io).
3. Upload index.html to the repository root.
4. Upload the assets folder, keeping japheth.jpg inside it.
5. Commit the changes.
6. Visit https://japhethrono28.github.io after GitHub Pages finishes updating.

Important: This package is a website update bundle. It does not make changes to GitHub until you upload and commit these files.
